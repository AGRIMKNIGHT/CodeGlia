let test () =
  (* todoruleid:useless-let *)
  let x = 3 in
  x
