let test1 () =
  (* ruleid:deprecated-pervasives *)
  let x = Pervasives.compare in
  x 1 2
