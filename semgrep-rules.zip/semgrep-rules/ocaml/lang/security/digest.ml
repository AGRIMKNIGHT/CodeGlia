(* ruleid:ocamllint-digest *)
let a = Digest.string "asd" in
  Printf.printf "%s\n" a
