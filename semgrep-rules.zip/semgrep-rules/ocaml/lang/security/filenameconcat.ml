(* ruleid:ocamllint-filenameconcat *)
let ofile = Filename.concat "test" "../data" in
Printf.printf "%s\n" ofile
